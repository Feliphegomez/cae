<?php
# FileName="Connection_php_mysql.htm"
# Type="MYSQL"
# HTTP="true"
$hostname_cae = "demedallo.com";
$database_cae = "demedall_deMedallo";
$username_cae = "demedall_caeuser";
$password_cae = "L[xS6)kst{GGt^bmHN";
$cae = mysql_pconnect($hostname_cae, $username_cae, $password_cae) or trigger_error(mysql_error(),E_USER_ERROR); 
?>