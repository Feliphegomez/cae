<?php
# FileName="Connection_php_mysql.htm"
# Type="MYSQL"
# HTTP="true"
$hostname_cae = "mysql11.000webhost.com";
$database_cae = "a8411780_cae";
$username_cae = "a8411780_caeuser";
$password_cae = "deMedallo.";
$cae = mysql_pconnect($hostname_cae, $username_cae, $password_cae) or trigger_error(mysql_error(),E_USER_ERROR); 
?>