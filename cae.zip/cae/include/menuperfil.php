
            <div class="box_c_content">
                <ul class="overview_list">
                    <li>
                        <a href="/users/<?php echo $row_cprofilesinfo['username']; ?>">
                            <img src="/img/blank.gif" style="background-image: url(/img/ico/open/ID.png)" />
                            <span class="ov_nb">&nbsp;</span>
                            <span class="ov_text">Informacion Personal</span>
                        </a>
                    </li>
                    <li>
                        <a href="/calendars/<?php echo $row_cprofilesinfo['username']; ?>">
                            <img src="/img/blank.gif" style="background-image: url(/img/ico/open/lamp.png)" />
                            <span class="ov_nb">&nbsp;</span>
                            <span class="ov_text">Horarios de Trabajo</span>
                        </a>
                    </li>
                </ul>
            </div>