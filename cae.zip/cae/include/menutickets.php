<style>

.inner_heading {
	opacity:1;
}

</style>

<ul class="cf">
    <li class="inner_heading"><img src="/img/ico/icSw2/32-Create-_-Write.png" style="float:left;" /><a style="float:left;"  href="/newticket/" class="mb_parent first_el">Nuevo Ticket</a></li>
    <li class="inner_heading"><img src="/img/ico/icSw2/32-Box-Outgoing-2.png" style="float:left;" /><a style="float:left;"  href="/inbox/" class="mb_parent first_el">Bandeja Entrada</a></li>
    <li class="inner_heading"><img src="/img/ico/icSw2/32-Inbox.png" style="float:left;" /><a style="float:left;"  href="/outbox/" class="mb_parent first_el">Bandeja Salida</a>
    </li>
</ul>