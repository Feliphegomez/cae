
            <div class="box_c_content">
                <ul class="overview_list">
                <li><h5>Datos Basicos</h5></li>
                <hr />
                	<li>Modificado Por: <a href="/users/<?php echo $row_cback['modby']; ?>"><?php echo $row_cback['modby']; ?></a></li>
                	<li>Dia de Modificacion: <a><?php echo $row_cback['dmod']; ?></a></li>
                	<li>Hora de Modificacion: <a><?php echo $row_cback['hmod']; ?> Horas</a></li>
                	<li>No Notificacion: <a><?php echo $row_cback['id']; ?></a></li>
                </ul>
            </div>
                    