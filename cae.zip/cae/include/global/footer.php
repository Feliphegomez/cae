<footer class="container" id="footer">
            <div class="row">
                <div class="twelve columns">
                    <center>Copyright © 2015 deMedallo.com - Creado & Diseñado por @FelipheGomez - Todos los derechos reservados.</center>
                </div>
            </div>
        </footer>