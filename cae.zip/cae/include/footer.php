<footer class="container" id="footer">
			<div class="row">
				<div class="twelve columns">
                    <center>Copyright © 2015 deMedallo.com - Creado & Diseñado por @FelipheGomez - Todos los derechos reservados.</center>
			  </div>
			</div>
		</footer>
        
        <div class="sw_width">
			<img class="sw_full" title="switch to full width" alt="" src="/img/blank.gif" />
			<img style="display:none" class="sw_fixed" title="switch to fixed width (980px)" alt="" src="/img/blank.gif" />
		</div>