	<head>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <title> CAE - Control y Asistencia de Empleados</title>
			<link rel="stylesheet" href="/foundation/stylesheets/foundation.css">
			<link rel="stylesheet" href="/lib/jQueryUI/css/Aristo/Aristo.css" media="all" />
			<link rel="stylesheet" href="/lib/jQplot/jquery.jqplot.css" media="all" />
			<link rel="stylesheet" href="/lib/fancybox/jquery.fancybox-1.3.4.css" media="all" />
			<link rel="stylesheet" href="/lib/fullcalendar/fullcalendar.css" media="all" />
			<link rel="stylesheet" href="/lib/qtip2/jquery.qtip.min.css" />
			<link rel="stylesheet" href="/css/style.css" />
            <link rel="stylesheet" href="/lib/datatables/css/demo_table_jui.css" media="all" />
			<link rel="shortcut icon" href="/favicon.ico" />
			<link rel="apple-touch-icon-precomposed" href="/icon.png" />
				
		<!--[if lt IE 9]>
			<link rel="stylesheet" href="/foundation/stylesheets/ie.css">
			<script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
			<script src="lib/jQplot/excanvas.min.js"></script>
		<![endif]-->
	</head>
